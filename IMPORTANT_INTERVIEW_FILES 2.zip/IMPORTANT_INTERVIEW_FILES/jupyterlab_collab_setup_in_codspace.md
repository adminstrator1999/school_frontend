# Jupyter Lab Collaboration Setup in github.com/Codespaces

Follow these steps to bypass Live Share and configure a real-time, Google Docs-style Jupyter Lab session via Port Forwarding.

---

## TL;DR — One Copy-Paste Block

Paste this whole thing into a Codespace terminal. It performs **Phase 0** (collaboration + Git) and **Phase 0.5** (IntelliSense / tab completion): installs everything into the Codespace-managed Python, enables the server extensions, writes the completion settings, verifies, and prints what to do next. It is safe to re-run.

```bash
bash <<'SETUP'
set -euo pipefail

# ---------------------------------------------------------------- 1. interpreter
# Use the Codespace-managed Python, NOT the venv. Fall back to whatever python3 is.
PY=/home/codespace/.python/current/bin/python3
[ -x "$PY" ] || PY="$(command -v python3)"
echo "==> Using interpreter: $PY"
"$PY" -V

# ---------------------------------------------------------------- 2. install
echo "==> Installing collaboration, git, LSP, and data packages (this takes a minute)..."
"$PY" -m pip install --upgrade --quiet \
  jupyter_collaboration \
  jupyterlab-git \
  jupyterlab-lsp \
  'python-lsp-server[all]' \
  pandas

# ---------------------------------------------------------------- 3. configure
echo "==> Writing Jupyter server + JupyterLab settings..."
"$PY" - <<'PYEOF'
import json, sys, sysconfig
from pathlib import Path

prefix = Path(sys.prefix)

def merge(path: Path, updates: dict) -> None:
    """Deep-merge `updates` into the JSON file at `path`, creating it if needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}
    for key, value in updates.items():
        if isinstance(value, dict):
            data.setdefault(key, {})
            if not isinstance(data[key], dict):
                data[key] = {}
            data[key].update(value)
        else:
            data[key] = value
    path.write_text(json.dumps(data, indent=2))
    print("   wrote", path)

# --- Server extensions: enable directly (jupyter server extension enable can fail validation)
merge(prefix / "etc/jupyter/jupyter_server_config.json", {
    "ServerApp": {
        "jpserver_extensions": {
            "jupyter_collaboration": True,
            "jupyterlab_git": True,
            "jupyter_lsp": True,
        }
    }
})

# --- JupyterLab settings: real IntelliSense instead of Tab-only completion
merge(prefix / "share/jupyter/lab/settings/overrides.json", {
    # Core completer: pop suggestions automatically, show the docs panel
    "@jupyterlab/completer-extension:manager": {
        "autoCompletion": True,
        "showDocumentationPanel": True,
        "providerTimeout": 1000,
    },
    # jupyterlab-lsp: keep refining suggestions while typing, runtime results first
    "@jupyter-lsp/jupyterlab-lsp:completion": {
        "continuousHinting": True,
        "kernelCompletionsFirst": True,
        "caseSensitive": False,
    },
    # Ctrl+hover for documentation popups
    "@jupyter-lsp/jupyterlab-lsp:hover": {
        "modifierKey": "Control",
    },
    # Near-instant sync for collaborators (Phase 4, done for you)
    "@jupyterlab/docmanager-extension:plugin": {
        "autosave": True,
        "autosaveInterval": 2,
    },
})
PYEOF

# ---------------------------------------------------------------- 4. verify
echo "==> Verifying..."
for mod in jupyter_collaboration jupyterlab_git jupyterlab_lsp pandas; do
  "$PY" -c "import $mod" 2>/dev/null \
    && echo "   OK   $mod" \
    || echo "   FAIL $mod  <-- check the pip output above"
done
PYLSP="$(dirname "$PY")/pylsp"
[ -x "$PYLSP" ] && echo "   OK   pylsp ($PYLSP)" || echo "   WARN pylsp not on PATH next to \$PY"
"$PY" -m jupyter server extension list 2>&1 | grep -Ei 'collaboration|git|lsp' || true

# ---------------------------------------------------------------- 5. next steps
cat <<'MSG'

==> DONE. Now:
  1. Restart Jupyter:  ps aux | grep jupyter-lab   then   kill <PID>
     (or close the JupyterLab tab and reopen it from the Codespace UI)
  2. Start it with collaboration:   jupyter lab --collaborative
  3. Copy the ?token=... from the output.
  4. Ports tab -> port 8888 -> Port Visibility = Public -> copy the forwarded URL.
  5. Send guest:  https://<forwarded-host>-8888.app.github.dev/?token=<token>
  6. BOTH users hard refresh (Ctrl+F5 / Cmd+Shift+R) -- extensions ship browser JS,
     so a stale tab will not have them.

  A "validation failed" X next to jupyter_collaboration is normal in Codespaces.
MSG
SETUP
```

> **Biggest gotcha:** completions come from the *language server's* environment, not the notebook kernel. If your kernel is a different venv, run `python -m pip install 'python-lsp-server[all]'` in that venv too, or third-party imports (e.g. `pandas`) won't resolve.

The phases below explain each step individually, for troubleshooting or if you'd rather run them by hand.

---

## Phase 0: Required Setup — Enable `jupyter_collaboration` and the Git Extension

These steps are **required** in a fresh Codespace. A plain `pip install` often installs into the wrong interpreter and `jupyter server extension enable` can fail validation, so install into the Codespace-managed Python and enable the extensions directly in the server config.

### 1. Install extensions into the Codespace's Python environment - NOT THE VENV!

```bash
# Install collaboration and Git extensions into the Codespace-managed Python
/home/codespace/.python/current/bin/python3 -m pip install --upgrade \
  jupyter_collaboration \
  jupyterlab-git
```

### 2. Verify the packages are importable

```bash
/home/codespace/.python/current/bin/python3 -c "import jupyter_collaboration; print('jupyter_collaboration OK')"
/home/codespace/.python/current/bin/python3 -c "import jupyterlab_git; print('jupyterlab_git OK')"
```

Both should print `OK`.

## 3: Start Server (Host)

1. Start the Jupyter Lab server (with collaboration enabled):

```bash
jupyter lab --collaborative
```

1. From the terminal output, locate the generated URL and copy **only the security token** (e.g., `?token=abc123def456`).

## 4: Expose to Guest (Host)

1. Open the **Ports** tab at the bottom of your VS Code window.
2. Find port `8888`, right-click it, and change **Port Visibility** to **Public**.
3. Click the copy icon next to the port to grab the forwarded Codespace URL.
4. Append the security token to this URL (e.g., `https://shiny-space-rotary-phone-rr5749qwv9xcp9vj-8888.app.github.dev/?token=5246907a2439bbe8c7cac97c7e48d9d0982599969febf550`).
5. Send the complete URL to your guest. They can paste it into a standard browser (Chrome/Edge) to sidestep Live Share completely.

## 5: Optimize Autosave (Host)

To make cell syncing feel instantaneous, reduce the autosave interval:

1. In Jupyter Lab, navigate to **Settings -> Advanced Settings Editor**.
2. Click on **Document Manager** in the left-hand menu.
3. Change the **Autosave Interval** from `120` to `2` or `3` (seconds).
4. Save the settings. Unsaved changes (the grey dot) will now sync and clear almost immediately.

Open the same notebook in two browser tabs (or share the URL with another user). You should see:

- Colored cursors per user
- Real-time syncing of edits
- RTC indicators in the UI

## IntelliSense and Tab Completion (Host)

Out of the box JupyterLab only gives you *kernel-based* completion (`Tab` after running a cell, `Shift + Tab` for a docstring). For real IntelliSense — static analysis, completion before execution, hover docs, go-to-definition, diagnostics, rename — install the LSP stack. Do this in the **same interpreter** used above.

### 1. Install the LSP extension and a Python language server

```bash
/home/codespace/.python/current/bin/python3 -m pip install --upgrade \
  jupyterlab-lsp \
  'python-lsp-server[all]'
```

`jupyterlab-lsp` is the JupyterLab front end; `python-lsp-server` is the actual language server (`[all]` pulls in jedi completion, rope rename, pyflakes/pycodestyle diagnostics).

> Optional extras: `pip install python-lsp-black pylsp-mypy` for format-on-save and type checking.

### 2. Verify

```bash
/home/codespace/.python/current/bin/python3 -c "import jupyterlab_lsp; print('jupyterlab_lsp OK')"
/home/codespace/.python/current/bin/pylsp --help >/dev/null && echo "pylsp OK"
jupyter labextension list 2>&1 | grep -i lsp
jupyter server extension list 2>&1 | grep -i lsp   # expect: jupyter_lsp enabled
```

`pylsp` must be on the **server's** `PATH`. If it isn't found, point the extension at it explicitly in the overrides file below via `language_servers`.

### 3. Turn on continuous (as-you-type) completion

The default still requires pressing `Tab`. Either set it in the UI — **Settings → Settings Editor → Code Completion** (check *Enable autocompletion*) and **Settings → Settings Editor → Language Servers / Completion** (check *Continuous hinting*) — or write the defaults for every user in the workspace:

```bash
python3 - <<'EOF'
import json
from pathlib import Path

settings_dir = Path("/home/codespace/.python/current/share/jupyter/lab/settings")
settings_dir.mkdir(parents=True, exist_ok=True)

overrides_file = settings_dir / "overrides.json"
overrides = json.loads(overrides_file.read_text()) if overrides_file.exists() else {}

# Core completer: pop suggestions up automatically, show the docs panel
overrides.setdefault("@jupyterlab/completer-extension:manager", {}).update({
    "autoCompletion": True,
    "showDocumentationPanel": True,
    "providerTimeout": 1000,
})

# jupyterlab-lsp: keep refining suggestions while typing, kernel results first
overrides.setdefault("@jupyter-lsp/jupyterlab-lsp:completion", {}).update({
    "continuousHinting": True,
    "kernelCompletionsFirst": True,
    "caseSensitive": False,
})

# Inline diagnostics / hover docs
overrides.setdefault("@jupyter-lsp/jupyterlab-lsp:hover", {}).update({
    "modifierKey": "Control",
})

overrides_file.write_text(json.dumps(overrides, indent=2))
print("Overrides written to:", overrides_file)
EOF
```

### 4. Restart and hard refresh

Restart the Jupyter server the same way as in Phase 0 step 4, then hard refresh the browser (`Ctrl + F5` / `Cmd + Shift + R`). Guests must hard refresh too — extensions ship JS to the browser, so a stale tab will not have them.

### 5. What you should now have

| Feature                     | How to use                                                                                   |
| --------------------------- | -------------------------------------------------------------------------------------------- |
| Auto-complete as you type   | Just type; menu appears (no`Tab` needed)                                                   |
| Manual completion           | `Tab`                                                                                      |
| Signature / docstring popup | `Shift + Tab`                                                                              |
| Hover documentation         | `Ctrl` + hover over a symbol                                                               |
| Go to definition            | `Ctrl + click`, or right-click → *Jump to definition*                                   |
| Diagnostics (lint/errors)   | Red/yellow underlines + the*Diagnostics Panel* (right-click → *Show diagnostics panel*) |
| Rename symbol               | Right-click →*Rename symbol* (`F2`)                                                     |

### 6. Smoke test — type this to prove it works

Open a **new notebook** with a **fresh kernel** and do *not* run anything yet. The point of the Cell 2 tests is that they must work **without executing a single cell** — that is what proves the *language server* is alive, not just the old kernel completer.

**Cell 1 — type it, but don't run it:**

```python
import pandas as pd
```

**Cell 2 — start typing, one test at a time:**

1. **Static completion.** Type `pd.read_c` and stop. A menu should appear on its own (no `Tab`) offering `read_csv`, `read_clipboard`. Each entry should show a type/detail label and a documentation panel on the side.
   *If nothing appears until you press `Tab`, `continuousHinting`/`autoCompletion` didn't apply — re-check step 3 and hard refresh.*
   *If nothing appears at all even with `Tab`, the language server isn't running — see troubleshooting below.*
2. **Signature help.** Type `pd.read_csv(` then press `Shift + Tab`. You should get the full signature and docstring popup.
3. **Hover docs.** Hold `Ctrl` and hover over `read_csv`. A documentation tooltip should appear.
4. **Diagnostics.** On a new line type an obvious problem and wait ~1 second:

   ```python
   import os
   undefined_name_xyz + 1
   ```

   You should get a yellow underline under `os` (imported but unused) and a red/yellow underline under `undefined_name_xyz` (undefined name). Right-click → *Show diagnostics panel* to see them listed.
5. **Go to definition / rename.** Type this, then `Ctrl + click` on the second `my_helper` — the cursor should jump to the `def`. With the cursor on it, `F2` should offer to rename every occurrence.

   ```python
   def my_helper(value):
       return value * 2

   my_helper(21)
   ```

**Cell 3 — now test the *kernel* completer (this one does need execution).** Run this cell:

```python
df = pd.DataFrame({"alpha_column": [1, 2], "beta_column": [3, 4]})
```

Then in a new cell type `df["a` and pause. You should be offered `alpha_column`. Column-name completion only comes from the live kernel — the language server can't know it — so if steps 1–5 worked but this doesn't, your notebook **kernel** is a different environment than the one you installed into (see the interpreter-mismatch note below).

Quick scorecard:

| Works                | Doesn't work                         | Likely cause                                                                                               |
| -------------------- | ------------------------------------ | ---------------------------------------------------------------------------------------------------------- |
| Nothing, even`Tab` | —                                   | Extension not loaded — hard refresh; check`jupyter server extension list` shows `jupyter_lsp enabled` |
| Only after`Tab`    | Auto-popup                           | `overrides.json` not applied — wrong prefix, or no hard refresh                                         |
| `pd.` completes    | `import pandas` shows "unresolved" | `pandas` missing from the **language server's** env                                                |
| Steps 1–5           | `df["a` columns                    | Notebook**kernel** is a different venv than the server                                               |
