# Senior Software Engineer AWS Interview Guide

Use this guide as an interviewer. Each section contains the full question, optional clarifications to offer only if the candidate asks for more context, what a strong answer should cover, a model answer, and useful follow-up probes.

---

## 1. Design a highly available API on AWS

### Interview question
**Design a highly available, production API on AWS for an application with internet-facing traffic. Walk through the architecture, the failure modes you are designing for, and how you would operate it.**

### Clarifications to provide if requested
- The API is public and serves authenticated mobile and web clients.
- Traffic is typically 500 requests per second, with bursts to 5,000 requests per second.
- It must tolerate the loss of a single Availability Zone without customer-visible outage.
- The initial deployment is single-Region; ask the candidate to explain when multi-Region would be justified.
- The application performs reads and writes to a transactional data store.
- Target availability is 99.9% initially; RTO is one hour and RPO is 15 minutes unless the candidate proposes a different business requirement.

### Strong answer should cover
- Multiple Availability Zones and removal of single points of failure.
- Stateless application design and externalized session state.
- Load balancing, health checks, autoscaling, and database availability.
- Observability, deployment safety, backup/restore, and explicit RTO/RPO trade-offs.
- A distinction between high availability within a Region and disaster recovery across Regions.

### Model answer
“I would start with Route 53, optionally CloudFront and AWS WAF at the edge, then place an Application Load Balancer in front of a stateless application tier spread across at least two Availability Zones. Depending on the workload, the application could run on ECS/Fargate, EKS, Lambda, or an EC2 Auto Scaling group. The choice should follow runtime needs, operational maturity, latency profile, and traffic behavior.

I would not keep sessions in an individual container or instance. I would use signed tokens where possible, or an external store such as ElastiCache if server-side state is required. For the transactional database, I would use a managed multi-AZ option such as Aurora or RDS Multi-AZ, with backups, point-in-time recovery, and connection management. Read replicas may help scale reads, but they are not a substitute for an availability design.

Operationally, I would define ALB and application health checks, autoscaling policies, alarms for error rate, p95 latency, saturation, and dependency failures, plus centralized structured logging and tracing. Deployments would use immutable artifacts and canary or blue/green rollout with automated rollback. Multi-Region would be a separate decision driven by measured business RTO/RPO, regional-risk tolerance, and the cost and consistency complexity of cross-Region data replication.”

### Follow-up probes
- “What changes if writes must be strongly consistent across two Regions?”
- “How would you prevent a database connection storm during an autoscaling event?”
- “Which metrics would page an engineer, versus create a ticket?”

---

## 2. Explain Multi-AZ, read replicas, and multi-Region replication

### Interview question
**Compare Multi-AZ deployment, read replicas, and multi-Region replication for a relational database on AWS. When would you use each, and what trade-offs would you call out?**

### Clarifications to provide if requested
- Assume an Aurora PostgreSQL or RDS PostgreSQL workload.
- The workload has a mix of transactional writes and reporting reads.
- The business is concerned about both an Availability Zone outage and a full regional outage.
- The candidate should address availability, read scaling, failover behavior, replication lag, data loss risk, and operational complexity.

### Strong answer should cover
- Multi-AZ as a high-availability mechanism within a Region.
- Read replicas as primarily a read-scaling mechanism, with replication-lag implications.
- Multi-Region replication as a disaster-recovery and/or latency pattern.
- RTO, RPO, cost, consistency, promotion/failover procedures, and application routing.

### Model answer
“Multi-AZ protects primarily against infrastructure failure within a Region by placing database capacity across Availability Zones and supporting failover. It is an availability feature, not a general read-scaling strategy. Read replicas are commonly used to offload read-heavy workloads such as reporting or product search, but replication can lag and the application must tolerate stale reads when using them.

Multi-Region replication addresses regional disaster recovery or global read latency. It adds more operational work: replication monitoring, DNS or traffic failover, credentials and network design, runbooks, and reconciliation if failover occurs with asynchronous replication. I would not choose among these by feature alone; I would first establish the required RTO and RPO. A low RPO across Regions often increases cost and application/data-model complexity, especially if the system requires strong write consistency.”

### Follow-up probes
- “How would you route read traffic safely to replicas?”
- “What is your database failover test plan?”
- “What data integrity issues could arise after a cross-Region failover?”

---

## 3. Design a reliable event-driven workflow

### Interview question
**Design a reliable event-driven workflow on AWS for processing order events. An event should cause inventory reservation, payment processing, and shipment creation. Assume downstream services can be slow or unavailable.**

### Clarifications to provide if requested
- Events may be delivered more than once and may arrive out of order.
- Processing should be asynchronous after the order is accepted.
- Payment is an external dependency and must not be charged twice.
- Failed messages must be recoverable without manually recreating them.
- The business wants auditability for every order state transition.

### Strong answer should cover
- At-least-once delivery and idempotent consumers.
- Durable queues or event buses, retries with backoff/jitter, DLQs, and replay.
- Correlation IDs, tracing, audit state, and event-schema versioning.
- Saga/compensation thinking for distributed workflows.
- Backpressure and protection of downstream dependencies.

### Model answer
“I would model the workflow as asynchronous and assume at-least-once delivery. The producer would publish a durable event, for example through EventBridge, SNS/SQS, or a queue-backed workflow. Each consumer would be idempotent using a stable order ID plus event ID or idempotency key. For payment, I would send the same idempotency key to the payment provider and persist the provider result before continuing, so retries cannot create duplicate charges.

Consumers would have bounded retries with exponential backoff and jitter. Messages that exhaust retries would go to a DLQ or failure destination, with alarms based on message age, queue depth, and DLQ arrivals. I would provide a controlled replay path after the underlying issue is fixed. The system would write an auditable state transition record and propagate a correlation ID through logs and traces.

For inventory, payment, and shipping, I would use a saga-style workflow rather than pretending the services participate in one distributed transaction. If payment succeeds but shipment creation fails permanently, the workflow needs a defined compensation or manual-resolution state, such as voiding/refunding payment and releasing inventory.”

### Follow-up probes
- “How would you preserve ordering where it truly matters?”
- “What would you store to make a consumer idempotent?”
- “How do you safely replay a DLQ without repeating successful side effects?”

---

## 4. Implement least-privilege IAM in production

### Interview question
**Describe how you would implement least-privilege IAM for both engineers and production workloads in a multi-account AWS environment.**

### Clarifications to provide if requested
- There are separate development, test, and production accounts.
- Engineers use a corporate identity provider.
- Applications run on Lambda, ECS, and EC2.
- Some teams need temporary operational access to production.
- The organization wants to prevent accidental public exposure and overbroad permissions.

### Strong answer should cover
- Federation and temporary credentials for people.
- IAM roles for workloads; no embedded access keys.
- Specific resource scoping, actions, and condition keys.
- Permission boundaries, service control policies, cross-account roles, and auditing.
- Access Analyzer, CloudTrail, MFA, emergency access, and periodic access review.

### Model answer
“I would separate accounts by environment and use AWS Organizations for governance. Engineers should authenticate through the corporate identity provider and assume role-based access using temporary credentials, rather than having long-lived IAM users and keys. Access should be role-based by job function, with stronger controls around production and a documented break-glass process protected by MFA and auditing.

Every workload should use an IAM role attached to its execution environment: a Lambda execution role, ECS task role, or EC2 instance profile. Policies should grant only the required actions against specific resources and, where useful, conditions such as a particular S3 prefix, VPC endpoint, source account, resource tag, or encryption requirement. I would use SCPs for account-wide non-negotiable guardrails and permission boundaries to constrain delegated administration.

Finally, I would enable CloudTrail, centralize logs, use IAM Access Analyzer to identify unintended public or external access, review unused permissions, and continuously test IAM policies in infrastructure-as-code pipelines.”

### Follow-up probes
- “Why is an IAM role safer than an access key in a CI/CD system?”
- “How would you allow one account to read a tightly scoped object prefix in another account?”
- “How would you investigate a denied API call without simply granting administrator access?”

---

## 5. Manage secrets and configuration securely

### Interview question
**How would you manage secrets, application configuration, and secret rotation across development, test, and production AWS environments?**

### Clarifications to provide if requested
- The system includes database credentials, third-party API credentials, feature flags, and ordinary configuration values.
- Containers and Lambda functions need access at runtime.
- Developers must be able to test locally without copying production secrets.
- At least one database credential should rotate automatically.

### Strong answer should cover
- Separation of secrets from ordinary configuration.
- Secrets Manager or Parameter Store selection and secure runtime retrieval.
- KMS encryption, IAM scoping, rotation, caching, and refresh behavior.
- Avoidance of source-control, image, environment-log, and CI-log leakage.
- Environment separation and incident response for compromised secrets.

### Model answer
“I separate non-sensitive configuration from credentials and other secrets. For ordinary configuration, I might use Parameter Store or a configuration service. For credentials that require lifecycle management and rotation, I would use AWS Secrets Manager. The application retrieves secrets at runtime using its IAM role, with a policy scoped to only the required secret and decrypt capability where applicable.

Secrets must not be stored in Git, committed into infrastructure code, baked into a container image, or written to CI logs. I would encrypt with KMS and grant access to keys separately where the risk model needs that separation. Applications should cache secrets for a reasonable period but be able to refresh them cleanly after rotation; database connection pools need to handle refreshed credentials without an outage.

For local development, I would provide a separate non-production secret set or a secure developer workflow, never production credentials. If a secret is exposed, I would revoke or rotate it, inspect access logs and deployment history, determine blast radius, and add a prevention control such as secret scanning or stricter pipeline redaction.”

### Follow-up probes
- “When would you choose Secrets Manager over Parameter Store?”
- “How do you rotate a database password without breaking live applications?”
- “What risks exist with secrets in environment variables?”

---

## 6. Respond to an accidentally public S3 bucket

### Interview question
**A security review reports that an S3 bucket may be public. Walk me through your response, from immediate containment through long-term prevention.**

### Clarifications to provide if requested
- The bucket contains a mixture of public web assets and internal documents.
- You do not yet know whether data was accessed externally.
- A production application depends on some objects being publicly reachable today.
- The organization uses Infrastructure as Code but has allowed manual console changes in the past.

### Strong answer should cover
- Confirm scope and urgency without delaying containment.
- S3 Block Public Access, bucket policy and ACL analysis, and safe public-content alternatives.
- Forensics: CloudTrail data events, access logs, object inventory/sensitivity, and policy history.
- Remediation that avoids breaking public website delivery.
- IaC enforcement, policy scanning, Access Analyzer, guardrails, and change controls.

### Model answer
“I would first identify whether public access is configured through the bucket policy, ACLs, access points, or an external cross-account policy, and determine what data is exposed. If sensitive objects may be publicly reachable, I would contain the exposure immediately using the least disruptive control—such as removing the public policy statement or applying S3 Block Public Access—while coordinating with the application owner.

Because public web assets may be legitimate, I would separate that use case from internal documents. A better pattern is often CloudFront in front of a private S3 origin using Origin Access Control, rather than making the bucket broadly public. I would inspect CloudTrail S3 data events and any access logs, determine the exposure window, identify the affected object set, and evaluate whether credential rotation, customer notification, or a formal incident process is required.

To prevent recurrence, I would move the bucket policy into Infrastructure as Code, disallow or tightly control console drift, use IAM Access Analyzer and automated policy checks, enforce organizational guardrails, and establish approved reusable patterns for static content and internal data.”

### Follow-up probes
- “What exact evidence would tell you whether objects were downloaded?”
- “How do Block Public Access settings interact with bucket policy and ACL configuration?”
- “How would you distinguish a harmless public asset from a reportable data exposure?”

---

## 7. Diagnose a slow and expensive Lambda service

### Interview question
**A Lambda-backed API is meeting functional requirements, but latency has increased and cost has doubled. How would you investigate and improve it?**

### Clarifications to provide if requested
- p95 latency increased from 300 ms to 2.5 seconds after a recent release.
- Invocation volume is roughly unchanged.
- The function calls a relational database and a third-party API.
- Some requests time out, but there are no obvious function errors.
- The function is invoked synchronously through API Gateway.

### Strong answer should cover
- Establishing baselines and inspecting duration, initialization, memory, concurrency, throttles, errors, and downstream latency.
- Structured logs, tracing, and correlation across dependencies.
- Reusing SDK/database clients, tuning memory, reducing initialization and package size.
- Connection management, concurrency limits, retries/timeouts, and architecture reconsideration.
- Cost per request and measurable before/after validation.

### Model answer
“I would begin by comparing before-and-after metrics: invocation count, billed duration, p50/p95/p99 duration, init duration, memory used, concurrency, throttles, errors, and timeout rate. I would use tracing to separate time spent in application code, database calls, DNS/TLS connection setup, and the third-party API. Since traffic is unchanged, a release-related code path or a slower dependency is more likely than a traffic-driven scaling issue.

I would look for expensive initialization inside the handler, clients created per invocation, repeated authentication calls, inefficient queries, excessive payload serialization, or retries that amplify latency. I would reuse AWS SDK clients and database connections outside the handler, use an appropriate connection-management approach such as RDS Proxy where applicable, set explicit timeouts and bounded retries, and tune Lambda memory because CPU allocation scales with memory.

I would validate each change with load tests and compare latency and cost per successful request. If the service has strict low-latency requirements with persistent connections or long-running work, I would evaluate whether Lambda is still the right compute model rather than forcing every workload into it.”

### Follow-up probes
- “Why can increasing Lambda memory reduce total cost?”
- “How would you prevent Lambda concurrency from overwhelming the database?”
- “When would provisioned concurrency be appropriate, and what is its trade-off?”

---

## 8. Reduce AWS cost without reducing reliability

### Interview question
**You are asked to reduce AWS spend by 20% while preserving production reliability and service-level objectives. How would you approach the problem?**

### Clarifications to provide if requested
- The footprint includes EC2, ECS/Fargate, RDS/Aurora, S3, CloudWatch Logs, NAT Gateways, and data transfer.
- The request is not permission to eliminate backups, monitoring, or tested disaster recovery.
- Teams currently have inconsistent cost tags.
- The target is three months, but changes must be safe and measurable.

### Strong answer should cover
- Cost visibility, allocation tags, ownership, and prioritizing the largest drivers.
- Rightsizing using utilization and SLO data, not guesses.
- Commitment discounts for stable workloads and Spot for interruption-tolerant workloads.
- Storage lifecycle policies, log retention, network/data-transfer architecture, and non-prod schedules.
- Guardrails, measurement, and avoiding false savings that increase outage risk.

### Model answer
“I would first make spend attributable: consistent tags for service, environment, team, and cost center; then use Cost Explorer, billing data, and utilization metrics to identify the largest and fastest-moving cost drivers. I would not start with small cosmetic savings when one oversized database, idle fleet, or cross-AZ/Internet data-transfer pattern dominates the bill.

For compute, I would rightsize from actual CPU, memory, throughput, latency, and saturation data. I would schedule or scale down non-production environments and use Autoscaling for variable load. For steady baseline workloads, I would evaluate Savings Plans or Reserved Instances; for fault-tolerant batch or worker workloads, Spot can be valuable if interruption handling is built in. For storage and logs, I would set explicit retention and lifecycle policies appropriate to business and regulatory requirements.

Every change needs a before/after metric, owner, rollback plan, and SLO protection. Cost optimization that removes redundancy, backups, or monitoring without revisiting risk requirements is not a real optimization; it is deferred operational cost.”

### Follow-up probes
- “How would you find and reduce unexpected NAT Gateway charges?”
- “Which workloads are poor candidates for Spot capacity?”
- “How would you prevent costs from regressing after the project ends?”

---

## 9. Build safe CI/CD for AWS applications and infrastructure

### Interview question
**Describe a CI/CD design for an AWS application and its infrastructure that allows frequent releases while minimizing production risk.**

### Clarifications to provide if requested
- The application includes a service, a database schema, IAM policies, and Terraform/CDK/CloudFormation infrastructure.
- Multiple teams contribute to the same AWS environment.
- Releases should be possible several times per week.
- A rollback must be achievable quickly.
- The service is customer-facing, so downtime is unacceptable for ordinary releases.

### Strong answer should cover
- Infrastructure as Code, versioning, review, testing, security/policy checks, and drift management.
- Immutable build artifacts promoted consistently through environments.
- Environment isolation and temporary credentials in CI.
- Progressive delivery, health checks, feature flags, rollback, and database migration safety.
- Deployment audit trails and operational ownership.

### Model answer
“I would manage the application and infrastructure as versioned code. A pull request would run unit and integration tests, linting, dependency and container scanning, IaC validation, and policy checks for unsafe IAM, networking, encryption, and public-access changes. The pipeline should authenticate to AWS using short-lived role assumptions through OIDC or another federated mechanism, not long-lived access keys.

The pipeline builds one immutable artifact and promotes that same artifact through development, test, staging, and production. Production releases use progressive delivery, such as canary, weighted routing, or blue/green deployment, with automated health checks based on error rate, latency, saturation, and selected business signals. Feature flags can further reduce blast radius, but they need ownership and expiration discipline.

For database changes, I use backward-compatible expand/contract migrations: add compatible schema first, deploy code that can handle both forms, backfill if needed, then remove obsolete schema only after the old version is gone. Rollback must be practiced; a deployment process is not safe merely because it has a rollback button.”

### Follow-up probes
- “How do you handle an IaC change that cannot be safely rolled back?”
- “What makes a database migration backward-compatible?”
- “How would you prove a canary is healthy before increasing traffic?”

---

## 10. Lead an incident involving a sudden API error spike

### Interview question
**You are the senior engineer on call. A customer-facing API error rate jumps from 0.1% to 12% shortly after a deployment. Explain your incident response, including technical investigation, mitigation, communication, and follow-up.**

### Clarifications to provide if requested
- The deployment completed 15 minutes ago.
- Errors occur in two Availability Zones, while traffic volume is normal.
- The API depends on a database and an external identity provider.
- A product manager and support team want status updates.
- You have authority to roll back or disable a feature flag.

### Strong answer should cover
- Rapid impact assessment and mitigation before deep root-cause analysis.
- Deployment correlation, dashboards, logs, traces, dependency checks, and hypothesis-driven investigation.
- Clear incident roles, customer/internal communication, and timestamps.
- Safe rollback or feature-disable decision making.
- Blameless but concrete post-incident review and tracked prevention work.

### Model answer
“My first objective is to reduce customer impact. I would declare or join the incident, establish an incident lead and communications owner if the process supports it, and confirm the scope using error rate, latency, traffic, deployment markers, health checks, and dependency dashboards. Since the spike follows a deployment and affects multiple AZs, I would treat the new release or a release-triggered dependency behavior as the leading hypothesis, but verify it rather than assuming it.

If the new deployment is the likely cause and rollback is low risk, I would roll back immediately or disable the relevant feature flag. In parallel, I would use correlation IDs, structured logs, and traces to identify the failing path and determine whether the database, identity provider, application configuration, or code change is involved. I would avoid a series of uncoordinated changes that make the incident harder to understand.

I would provide scheduled, factual updates: customer impact, current mitigation, and next update time—not speculation. After recovery, I would create a timeline, document root cause and contributing conditions, identify detection gaps, and assign concrete prevention actions such as an added canary check, improved rollout gate, dependency fallback, test coverage, dashboard, or runbook. The review should be blameless, but the corrective actions must have accountable owners and due dates.”

### Follow-up probes
- “When would you roll back versus continue investigating?”
- “What should an effective customer-facing status update say during uncertainty?”
- “Give examples of action items that prevent recurrence rather than merely document the outage.”

---

## Interviewer evaluation rubric

| Dimension | Strong senior-level signal | Concern signal |
|---|---|---|
| Architecture | Explains trade-offs, failure domains, RTO/RPO, and operational consequences | Names AWS services without explaining why or how they fail |
| Reliability | Assumes retries, duplicates, timeouts, and partial failure | Assumes synchronous calls and exactly-once behavior without safeguards |
| Security | Uses federated identity, roles, scoped permissions, auditing, and guardrails | Suggests shared keys, administrator policies, or security by convention |
| Operations | Defines alarms, logs, traces, runbooks, rollout and rollback | Treats deployment as the end of engineering work |
| Cost | Measures usage and protects SLOs while optimizing | Equates cost savings with deleting redundancy or monitoring |
| Communication | States assumptions, asks for requirements, and gives a structured plan | Gives vague answers or refuses to make justified decisions under uncertainty |
